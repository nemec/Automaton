__all__ = ["echo", "exe", "google", "memo", "translate",
          "wiki", "mail", "say", "scores", "run", "map",
          "upload", "latitude", "music", "weather", "gettime",
          "pandora", "schedule"]
